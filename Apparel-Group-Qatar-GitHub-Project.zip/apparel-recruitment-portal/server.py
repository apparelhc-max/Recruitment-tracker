"""Local recruitment portal. Python 3.10+; no third-party runtime dependencies."""
import base64
from contextlib import closing
import csv
import getpass
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import sqlite3
import sys
import threading
import time
import zipfile
from datetime import date, datetime
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("PORTAL_DB", str(ROOT / "data" / "portal.sqlite3")))
HOST = os.getenv("PORTAL_HOST", "127.0.0.1")
PORT = int(os.getenv("PORTAL_PORT", "8080"))
SESSION_AGE = 8 * 3600
MAX_BODY = 16 * 1024 * 1024
ATTEMPTS = {}
ATTEMPTS_LOCK = threading.Lock()
HEADERS = {
    "name": ["candidate name", "name", "candidate"],
    "brand": ["brand", "division", "brand division"],
    "designation": ["designation", "position", "job title", "role"],
    "manager": ["area managers", "area manager", "manager", "region", "area"],
    "status": ["visa document status", "visa status", "status", "recruitment status"],
    "gender": ["gender", "sex"],
    "nationality": ["nationality", "country", "citizenship"],
    "source": ["source", "source of recruitment", "recruitment source"],
    "notes": ["notes", "feedback", "remarks", "comments"],
    "salary": ["gross salary", "salary"],
    "notice": ["notice", "notice period"],
}


def connect():
    db = sqlite3.connect(DB_PATH, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA busy_timeout=15000")
    return db


def setup():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with closing(connect()) as db, db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
          password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','manager')),
          manager_tag TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS candidates (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, brand TEXT NOT NULL DEFAULT '',
          designation TEXT NOT NULL DEFAULT '', manager_tag TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT '', gender TEXT NOT NULL DEFAULT '',
          nationality TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS candidates_manager_idx ON candidates(manager_tag COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT OR IGNORE INTO meta(key,value) VALUES('revision','0');
        CREATE TABLE IF NOT EXISTS audit (
          id INTEGER PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
          detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)
        # Allow the app to open a database created by the preceding local prototype.
        if "source" not in {r[1] for r in db.execute("PRAGMA table_info(candidates)")}:
            db.execute("ALTER TABLE candidates ADD COLUMN source TEXT NOT NULL DEFAULT ''")
        if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
            password = os.getenv("PORTAL_ADMIN_PASSWORD", "")
            if not password and sys.stdin.isatty():
                print("First launch: create the administrator password (at least 12 characters).")
                password = getpass.getpass("New admin password: ")
                confirmation = getpass.getpass("Repeat admin password: ")
                if password != confirmation:
                    raise SystemExit("Passwords did not match. Run the server again.")
            if len(password) < 12:
                raise SystemExit("First launch: choose an admin password of at least 12 characters, or set PORTAL_ADMIN_PASSWORD for automated setup.")
            username = os.getenv("PORTAL_ADMIN_USER", "admin").strip()
            db.execute("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,'admin')",
                       ("Super Administrator", username, hash_password(password)))
            print(f"Created administrator account: {username}")


def hash_password(password):
    salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return f"pbkdf2_sha256$310000${salt.hex()}${key.hex()}"


def verify_password(password, stored):
    try:
        _, rounds, salt, expected = stored.split("$")
        got = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(rounds))
        return hmac.compare_digest(got, bytes.fromhex(expected))
    except (ValueError, TypeError):
        return False


def bump(db):
    db.execute("UPDATE meta SET value=CAST(value AS INTEGER)+1 WHERE key='revision'")


def audit(db, actor, action, detail=""):
    db.execute("INSERT INTO audit(actor,action,detail) VALUES(?,?,?)", (actor, action, detail[:500]))


def normal(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def cell(value):
    if value is None:
        return ""
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value).strip()[:2000]


def ods_rows(raw):
    # Basic ODS table reader using only the standard library.
    ns = {"t": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
          "x": "urn:oasis:names:tc:opendocument:xmlns:text:1.0"}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        root = ET.fromstring(archive.read("content.xml"))
    table = root.find(".//t:table", ns)
    if table is None:
        return []
    rows = []
    for row in table.findall("t:table-row", ns):
        line = []
        for entry in row:
            if entry.tag not in (f"{{{ns['t']}}}table-cell", f"{{{ns['t']}}}covered-table-cell"):
                continue
            value = " ".join((p.text or "") for p in entry.findall(".//x:p", ns)).strip()
            repeat = min(int(entry.get(f"{{{ns['t']}}}number-columns-repeated", "1")), 200)
            line.extend([value] * repeat)
        if any(line):
            rows.extend([line] * min(int(row.get(f"{{{ns['t']}}}number-rows-repeated", "1")), 1000))
        if len(rows) > 20_001:
            break
    return rows


def parse_sheet(filename, raw):
    suffix = Path(filename).suffix.lower()
    if suffix == ".csv":
        rows = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"))))
    elif suffix == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError:
            raise ValueError("XLSX import requires: pip install openpyxl")
        book = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        try:
            rows = list(book.active.values)
        finally:
            book.close()
    elif suffix == ".ods":
        rows = ods_rows(raw)
    else:
        raise ValueError("Use a .xlsx, .ods, or .csv file.")
    if len(rows) > 20_000:
        raise ValueError("This file exceeds the 20,000-row import limit.")
    if not rows:
        raise ValueError("The spreadsheet is empty.")
    aliases = {field: set(names) for field, names in HEADERS.items()}
    best = max(range(min(20, len(rows))), key=lambda i:
               sum(normal(v) in set().union(*aliases.values()) for v in rows[i]))
    headings = [normal(v) for v in rows[best]]
    columns = {field: next((i for i, heading in enumerate(headings) if heading in names), None)
               for field, names in aliases.items()}
    if columns["name"] is None or columns["manager"] is None:
        raise ValueError("The sheet needs Candidate Name and Area Manager columns. No data was changed.")

    def take(row, key):
        index = columns[key]
        return cell(row[index]) if index is not None and index < len(row) else ""

    result = []
    for row_number, row in enumerate(rows[best + 1:], best + 2):
        name, manager = take(row, "name"), take(row, "manager")
        if not any(cell(v) for v in row):
            continue
        if not name or not manager:
            raise ValueError(f"Row {row_number} needs a candidate name and area manager. No data was changed.")
        notes = take(row, "notes")
        extras = [f"Salary: {take(row, 'salary')}" if take(row, "salary") else "",
                  f"Notice: {take(row, 'notice')}" if take(row, "notice") else ""]
        notes = " | ".join(filter(None, [notes, *extras]))
        result.append((name, take(row, "brand"), take(row, "designation"), manager,
                       take(row, "status") or "New", take(row, "gender"), take(row, "nationality"),
                       take(row, "source"), notes))
    if not result:
        raise ValueError("No candidate records were found. No data was changed.")
    return result


class Handler(BaseHTTPRequestHandler):
    server_version = "RecruitmentPortal/1.0"

    def log_message(self, fmt, *args):
        print(f"{self.address_string()} - {fmt % args}")

    def respond(self, status, data, cookie=None):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ValueError("Send JSON with Content-Type: application/json.")
        length = int(self.headers.get("Content-Length", "0"))
        if length < 1 or length > MAX_BODY:
            raise ValueError("Request is empty or exceeds the 16 MB limit.")
        return json.loads(self.rfile.read(length))

    def user(self, db):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            token = cookie["portal_session"].value
        except Exception:
            return None
        row = db.execute("""SELECT u.id,u.username,u.name,u.role,u.manager_tag FROM sessions s
                          JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?
                          AND u.active=1""", (hashlib.sha256(token.encode()).hexdigest(), int(time.time()))).fetchone()
        return dict(row) if row else None

    def same_origin(self):
        if self.headers.get("Sec-Fetch-Site", "same-origin") not in ("same-origin", "none"):
            return False
        origin = self.headers.get("Origin")
        if not origin:
            return True
        return urlparse(origin).netloc == self.headers.get("Host") and urlparse(origin).scheme in ("http", "https")

    def route(self):
        path = urlparse(self.path).path
        if not path.startswith("/api/"):
            if self.command != "GET":
                return self.respond(405, {"error": "Method not allowed"})
            name = "/index.html" if path == "/" else path
            if name not in ("/index.html", "/app.js", "/styles.css"):
                return self.respond(404, {"error": "Not found"})
            mime = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8"}
            body = (ROOT / "public" / name.lstrip("/")).read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mime[Path(name).suffix])
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            return self.wfile.write(body)
        if self.command != "GET" and not self.same_origin():
            return self.respond(403, {"error": "Cross-site request blocked."})
        if self.command != "GET" and self.headers.get("X-Portal-Request") != "1":
            return self.respond(403, {"error": "Request verification failed."})
        with closing(connect()) as db, db:
            if path == "/api/login" and self.command == "POST":
                data = self.read_json()
                username, password = str(data.get("username", "")).strip(), str(data.get("password", ""))
                attempt_key = (self.client_address[0], username.casefold())
                now = time.time()
                with ATTEMPTS_LOCK:
                    recent = [t for t in ATTEMPTS.get(attempt_key, []) if now-t < 900]
                    ATTEMPTS[attempt_key] = recent
                    locked = len(recent) >= 10
                if locked:
                    return self.respond(429, {"error": "Too many attempts. Try again in 15 minutes."})
                found = db.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
                # Perform comparable work for unknown usernames.
                stored = found["password_hash"] if found else hash_password("invalid-login-placeholder")
                if not found or not verify_password(password, stored):
                    with ATTEMPTS_LOCK:
                        ATTEMPTS[attempt_key].append(now)
                    return self.respond(401, {"error": "Invalid username or password."})
                with ATTEMPTS_LOCK:
                    ATTEMPTS.pop(attempt_key, None)
                token = secrets.token_urlsafe(32)
                db.execute("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)",
                           (hashlib.sha256(token.encode()).hexdigest(), found["id"], int(time.time()) + SESSION_AGE))
                db.commit()
                cookie = f"portal_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_AGE}"
                if os.getenv("PORTAL_HTTPS") == "1":
                    cookie += "; Secure"
                return self.respond(200, {"ok": True}, cookie)
            user = self.user(db)
            if not user:
                return self.respond(401, {"error": "Please sign in."})
            if path == "/api/logout" and self.command == "POST":
                cookie = SimpleCookie()
                cookie.load(self.headers.get("Cookie", ""))
                if "portal_session" in cookie:
                    db.execute("DELETE FROM sessions WHERE token_hash=?", (hashlib.sha256(cookie["portal_session"].value.encode()).hexdigest(),))
                db.commit()
                return self.respond(200, {"ok": True}, "portal_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            if path == "/api/me" and self.command == "GET":
                return self.respond(200, {"user": user})
            if path == "/api/password" and self.command == "POST":
                data = self.read_json()
                old, new = str(data.get("current", "")), str(data.get("new", ""))
                stored = db.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()[0]
                if not verify_password(old, stored):
                    return self.respond(400, {"error": "Current password is incorrect."})
                if len(new) < 12 or len(new) > 128:
                    return self.respond(400, {"error": "Choose a password between 12 and 128 characters."})
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(new), user["id"]))
                db.execute("DELETE FROM sessions WHERE user_id=?", (user["id"],))
                audit(db, user["username"], "change_password")
                db.commit()
                return self.respond(200, {"ok": True}, "portal_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            if path == "/api/candidates" and self.command == "GET":
                if user["role"] == "admin":
                    rows = db.execute("SELECT * FROM candidates ORDER BY id DESC").fetchall()
                else:
                    rows = db.execute("SELECT * FROM candidates WHERE manager_tag=? COLLATE NOCASE ORDER BY id DESC",
                                      (user["manager_tag"],)).fetchall()
                revision = db.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0]
                return self.respond(200, {"candidates": [dict(r) for r in rows], "revision": revision})
            if path.startswith("/api/candidates/"):
                try:
                    record_id = int(path.rsplit("/", 1)[1])
                except ValueError:
                    return self.respond(404, {"error": "Record not found."})
                row = db.execute("SELECT id,manager_tag FROM candidates WHERE id=?", (record_id,)).fetchone()
                if not row or (user["role"] != "admin" and row["manager_tag"].casefold() != user["manager_tag"].casefold()):
                    return self.respond(404, {"error": "Record not found."})
                if self.command == "PATCH":
                    note = str(self.read_json().get("notes", "")).strip()[:2000]
                    db.execute("UPDATE candidates SET notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (note, record_id))
                    bump(db)
                    audit(db, user["username"], "note", str(record_id))
                    db.commit()
                    return self.respond(200, {"ok": True})
                if self.command == "DELETE" and user["role"] == "admin":
                    db.execute("DELETE FROM candidates WHERE id=?", (record_id,))
                    bump(db)
                    audit(db, user["username"], "delete_candidate", str(record_id))
                    db.commit()
                    return self.respond(200, {"ok": True})
            if user["role"] != "admin":
                return self.respond(403, {"error": "Administrator access required."})
            if path == "/api/managers" and self.command == "GET":
                rows = db.execute("SELECT id,name,username,manager_tag,active,created_at FROM users WHERE role='manager' ORDER BY name").fetchall()
                return self.respond(200, {"managers": [dict(r) for r in rows]})
            if path == "/api/managers" and self.command == "POST":
                data = self.read_json()
                name, username, tag = (str(data.get(k, "")).strip() for k in ("name", "username", "manager_tag"))
                if not name or not tag or not re.fullmatch(r"[a-zA-Z0-9._-]{3,40}", username):
                    return self.respond(400, {"error": "Enter a name, manager tag, and username (3–40 letters, digits, . _ or -)."})
                password = secrets.token_urlsafe(18)
                try:
                    db.execute("INSERT INTO users(name,username,password_hash,role,manager_tag) VALUES(?,?,?,'manager',?)",
                               (name[:120], username, hash_password(password), tag[:120]))
                except sqlite3.IntegrityError:
                    return self.respond(409, {"error": "That username already exists."})
                audit(db, user["username"], "create_manager", username)
                db.commit()
                return self.respond(201, {"username": username, "password": password})
            match = re.fullmatch(r"/api/managers/(\d+)/(reset|toggle)", path)
            if match and self.command == "POST":
                target = db.execute("SELECT id,username,active FROM users WHERE id=? AND role='manager'", (int(match[1]),)).fetchone()
                if not target:
                    return self.respond(404, {"error": "Manager not found."})
                if match[2] == "reset":
                    password = secrets.token_urlsafe(18)
                    db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(password), target["id"]))
                    db.execute("DELETE FROM sessions WHERE user_id=?", (target["id"],))
                    audit(db, user["username"], "reset_password", target["username"])
                    db.commit()
                    return self.respond(200, {"username": target["username"], "password": password})
                db.execute("UPDATE users SET active=? WHERE id=?", (0 if target["active"] else 1, target["id"]))
                db.execute("DELETE FROM sessions WHERE user_id=?", (target["id"],))
                audit(db, user["username"], "toggle_manager", target["username"])
                db.commit()
                return self.respond(200, {"ok": True})
            if path == "/api/import" and self.command == "POST":
                data = self.read_json()
                filename = str(data.get("filename", ""))
                try:
                    raw = base64.b64decode(data["base64"], validate=True)
                except (KeyError, ValueError):
                    raise ValueError("Invalid file data.")
                if len(raw) > 10 * 1024 * 1024:
                    raise ValueError("The file exceeds the 10 MB limit.")
                rows = parse_sheet(filename, raw)
                previous = {(normal(r["name"]), normal(r["manager_tag"]), normal(r["designation"])): r["notes"]
                            for r in db.execute("SELECT name,manager_tag,designation,notes FROM candidates")}
                db.execute("DELETE FROM candidates")
                db.executemany("""INSERT INTO candidates(name,brand,designation,manager_tag,status,gender,nationality,source,notes)
                              VALUES(?,?,?,?,?,?,?,?,?)""",
                               [(*r[:8], previous.get((normal(r[0]), normal(r[3]), normal(r[2])), r[8])) for r in rows])
                bump(db)
                audit(db, user["username"], "import", f"{filename}: {len(rows)} rows")
                db.commit()
                return self.respond(200, {"count": len(rows)})
            return self.respond(404, {"error": "Not found."})

    def do_GET(self):
        self.safe_route()

    def do_POST(self):
        self.safe_route()

    def do_PATCH(self):
        self.safe_route()

    def do_DELETE(self):
        self.safe_route()

    def safe_route(self):
        try:
            self.route()
        except (ValueError, json.JSONDecodeError, zipfile.BadZipFile, ET.ParseError, UnicodeError) as error:
            self.respond(400, {"error": str(error)[:300]})
        except BrokenPipeError:
            pass
        except Exception as error:
            print(f"Request failed: {error}", file=sys.stderr)
            self.respond(500, {"error": "Server error. Check the server log."})


if __name__ == "__main__":
    setup()
    print(f"Recruitment portal listening on http://{HOST}:{PORT}")
    if HOST not in ("127.0.0.1", "localhost", "::1"):
        print("LAN mode: place the server behind HTTPS before handling real candidate information.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
