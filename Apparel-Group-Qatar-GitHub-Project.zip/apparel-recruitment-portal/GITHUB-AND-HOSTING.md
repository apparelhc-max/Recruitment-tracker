# Put the portal on GitHub and host it

There are two different jobs here:

| Job | Where it happens | What people can do |
| --- | --- | --- |
| Store and update the source code | A **private GitHub repository** | Developers/IT can review and download code |
| Run the real portal | Your **company Windows server**, behind HTTPS | Admins and managers can sign in and work with shared records |
| Show a sample in a browser (optional) | GitHub Pages using `docs/index.html` | Anyone with the demo link sees **fictional sample data only** |

GitHub Pages cannot run `server.py`, SQLite, or real login. Never put real candidate data, a database, or passwords in the GitHub repository or the public demo.

## Part A — Test the live portal on your own Windows computer

1. Download the ZIP supplied with this guide. In File Explorer, right-click it and select **Extract All**. Go inside the extracted `apparel-recruitment-portal` folder. You should see `server.py`, `README.md`, and `public` directly inside it.
2. Install **Python 3.10 or newer**. The Python Install Manager in the Microsoft Store is one option. Restart PowerShell after installation.
3. In File Explorer, open the `apparel-recruitment-portal` folder. Click the address bar, type `powershell`, and press Enter.
4. Type `python --version` and press Enter. It should print a Python version. Then install the Excel importer:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the live app:

   ```powershell
   python server.py
   ```

6. On the **very first start**, type an admin password of at least 12 characters and press Enter. Type it again when prompted. PowerShell intentionally shows **no characters** as you type. Save the password in your company's approved password manager. The username is `admin`.
7. Leave PowerShell open. In Edge or Chrome on that same computer, open <http://127.0.0.1:8080>. Sign in. To practice, select **Data import** and upload `sample-demo.csv`; its records are fictional.
8. To stop the trial, go back to PowerShell and press **Ctrl+C**. On future starts, repeat step 5; it does not ask you to create the admin password again.

If Python is not recognized, close PowerShell and reopen it. If port 8080 is occupied, enter `$env:PORTAL_PORT = "8081"` before step 5, and use <http://127.0.0.1:8081> instead.

## Part B — Upload the complete code to GitHub

These steps use **GitHub Desktop**, which is easier than typing Git commands. You need a GitHub account and GitHub Desktop installed.

1. On your own computer, keep the extracted `apparel-recruitment-portal` folder from Part A. In GitHub Desktop, sign in to your GitHub account.
2. Choose **File → Add local repository**. Select the extracted **`apparel-recruitment-portal` folder**, not its parent ZIP file.
3. GitHub Desktop may say the folder is not yet a Git repository. Choose **Create a Repository Here**. Name it `apparel-recruitment-portal`, then create it.
4. In the **Changes** tab, check the files. You should see `server.py`, `public/`, `docs/`, `README.md`, and the guide. You should **not** see `portal.sqlite3`, `backups/`, `.env`, a real HR spreadsheet, or passwords. If you do, **stop before committing**, remove them from the folder, and ask IT to check the Git history.
5. Enter a summary such as `Initial recruitment portal` and click **Commit to main**.
6. Click **Publish repository**. Keep **Keep this code private** checked. Choose the correct company GitHub organization as the owner if your organization has approved one. Click **Publish Repository**.
7. Click **View on GitHub** in Desktop and check the files online. The source code is now backed by GitHub. The live portal is still only running wherever you started `server.py`.

For later code changes: in Desktop review **Changes**, enter a summary, **Commit to main**, then **Push origin**. IT should test and deploy the update to the company server. Never drag a populated `data` or `backups` folder into the website or upload your real spreadsheet to the repository.

## Part C — Host the real portal on the company network (IT installation)

Your IT team needs an always-on Windows server or VM, a company DNS name, and HTTPS certificate management. These steps are a concrete handoff for IT.

1. On the server, install Python 3.10 or newer. Get the project code from the **private** repository into `C:\RecruitmentPortal` using the company's approved Git method. Run:

   ```powershell
   cd C:\RecruitmentPortal
   python -m pip install -r requirements.txt
   ```

2. Create `C:\RecruitmentPortalData` with read/write access only for a dedicated portal service account and authorized backup operators. Keep it **outside** the Git checkout. In a PowerShell window **under that account**, initialize the database and admin password:

   ```powershell
   $env:PORTAL_DB = "C:\RecruitmentPortalData\portal.sqlite3"
   $env:PORTAL_HTTPS = "1"
   python server.py
   ```

   Enter the new admin password when prompted. When the server says it is listening, press **Ctrl+C** to stop the interactive initialization. These environment variables must also be set for the managed service in step 5. Do not put passwords into environment variables, scripts, Git commits, or service command lines.

3. Choose the approved internal name, for example `recruitment.company.internal`, and point DNS at this server. Configure your organization's approved HTTPS reverse proxy to forward that name to `http://127.0.0.1:8080`. An example for Caddy is supplied in `Caddyfile.example`:

   ```caddyfile
   recruitment.company.internal {
       tls internal
       reverse_proxy 127.0.0.1:8080
   }
   ```

   Replace the name. With `tls internal`, IT must distribute and trust the proxy's internal root certificate on **every user's computer**, or use a certificate issued by the company's already-trusted CA. Avoid browser certificate warnings; they mean the HTTPS setup is incomplete.

4. Keep the Python app listening on **127.0.0.1**, not `0.0.0.0`. In the server firewall allow inbound **TCP 443 only from the intended company network**; do not allow inbound 8080. Limit access further using your company VPN or network rules when needed. Make sure the reverse proxy passes the original `Host` header; the supplied Caddy setup does this.
5. IT should configure **both the Python server and HTTPS proxy to start automatically as managed background services** under suitable accounts. The Python service must start with `PORTAL_DB=C:\RecruitmentPortalData\portal.sqlite3` and `PORTAL_HTTPS=1`, and run `python C:\RecruitmentPortal\server.py`. Start only after the interactive initialization in step 2. Restart the services after code changes. Keep service logs protected and monitor failures.
6. On a manager's workstation, open `https://recruitment.company.internal`. Admin signs in and creates manager accounts in **Managers**, using manager tags exactly matching the master spreadsheet's `Area Manager` column. Give each person their generated password through an approved private channel; have them change it using the gear icon. Test with two manager accounts that each sees only its own assigned candidates. Then import the real tracker through **Data import**.

### Backups and maintenance

- The live database belongs on the server, never on GitHub. Back it up regularly with SQLite's online backup API, using the same `PORTAL_DB` as the service:

  ```powershell
  $env:PORTAL_DB = "C:\RecruitmentPortalData\portal.sqlite3"
  $env:PORTAL_BACKUP_DIR = "C:\RecruitmentPortalData\backups"
  cd C:\RecruitmentPortal
  python backup.py
  ```

- Protect and separately copy backups according to your company policy; test restoring one in an isolated installation. Do not commit any backup.
- Updating code from GitHub does not replace the external database. Test updates on a copy first, and take a backup before deploying.
- Before organization-wide use, IT/security should approve access policy, SSO/MFA plans, backup recovery, software updates, retention, and audit review. A pilot with real data also needs the same access and HTTPS controls.

## Part D — Optional fictional GitHub Pages preview

The `docs/index.html` file is a visual preview with a fixed fictional sample. It is read-only: its manager selector is a visual filter, and it has no real sign-in, shared storage, or live data.

**If your company permits a public brand demo**, create a **separate public repository containing only a copy of `docs/index.html` at its root**, then in that repository choose **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save**. GitHub will show a URL like `https://YOUR-ACCOUNT.github.io/YOUR-DEMO-REPOSITORY/`. Do **not** change the complete source repository to public just to enable Pages. If your company does not permit a public demo, skip Part D entirely.
