"""Create a consistent SQLite backup while the portal may be running."""
from datetime import datetime
import os
from pathlib import Path
from sqlite3 import connect
from server import DB_PATH

if not DB_PATH.exists():
    raise SystemExit("No database yet. Start server.py at least once.")
folder = Path(os.getenv("PORTAL_BACKUP_DIR", str(Path(__file__).resolve().parent / "backups")))
folder.mkdir(parents=True, exist_ok=True)
target = folder / f"portal-{datetime.now().strftime('%Y%m%d-%H%M%S')}.sqlite3"
with connect(DB_PATH) as source, connect(target) as destination:
    source.backup(destination)
print(f"Backup saved: {target}")
