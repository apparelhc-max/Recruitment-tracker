# Apparel Group Qatar · Recruitment Portal

A recruitment dashboard for an internal Windows or Linux server. Includes administrator and area-manager accounts, spreadsheet imports, candidate notes, dashboard charts, exports, audit events, and an administrator password-change screen.

**Begin here:** [GitHub and hosting instructions](GITHUB-AND-HOSTING.md). The instructions start with a single-computer trial and then explain a company-network installation.

## Which files do what?

| Path | Purpose |
| --- | --- |
| `server.py` | Python web server, accounts, authorization, and database |
| `public/` | Live dashboard served by `server.py` |
| `sample-demo.csv` | Fictional records for testing imports |
| `backup.py` | Consistent backup of the SQLite database |
| `docs/index.html` | Public-safe, fictional, read-only GitHub Pages preview |
| `Caddyfile.example` | Example HTTPS gateway configuration for IT |
| `requirements.txt` | Excel `.xlsx` import dependency |
| `.gitignore` | Excludes the database, backups, logs, and local secrets from Git |

**GitHub stores the project code; it does not run the live Python portal.** GitHub Pages may show only `docs/index.html`, which uses fictional data and has no actual account or database. The live app runs with `python server.py` on a company-controlled machine. Do not put candidate information into `docs/` or into a Git commit.

## Quick single-computer trial

1. Install Python 3.10 or newer. Open PowerShell in this folder.
2. Run `python -m pip install -r requirements.txt`.
3. Run `python server.py`; enter and repeat a new admin password of at least 12 characters at the first-run prompt. Nothing displays while you type it.
4. Keep PowerShell open. Visit <http://127.0.0.1:8080> and sign in as `admin` with the password you just set.
5. Open **Data import** and import `sample-demo.csv` to see fictional dashboard records.

Closing PowerShell stops the trial server. Do not open `public/index.html` directly: the live dashboard needs the Python server.

## Using the app

- **Managers:** create an account with a manager tag matching the `Area Manager` column in your spreadsheet. Copy the generated password when displayed; it is shown once. An admin can reset it or disable the account later. Managers only receive records assigned to their tag.
- **Change admin password:** sign in as admin, open **Managers → Change admin password**, enter your current and new passwords, then sign in again. Existing admin sessions are revoked. The gear icon also lets any signed-in user change their own password.
- **Data import:** upload a `.xlsx`, `.ods`, or `.csv` file. Every valid import replaces the candidate list; existing edited notes are retained when the candidate name, manager tag, and designation match. Invalid imports leave the previous list intact.
- **Candidates:** search, filter, edit a note, and export your currently visible records as CSV. Admins may delete records. Data on an open dashboard refreshes about every 15 seconds.

The first worksheet must include **Candidate Name** (or `Name`) and **Area Manager** (or `Area Managers`) within the first 20 rows. Every populated candidate row needs both values. Other recognized headers include `Brand`, `Designation`, `Visa/ Document Status`, `Gender`, `Nationality`, `Source of Recruitment`, `Notes`, `Gross Salary`, and `Notice`. Import limit: 10 MB and 20,000 rows. Save an old `.xls` file as `.xlsx` first.

## Deployment notes for IT

The server listens on `127.0.0.1:8080` by default. Put it behind an HTTPS reverse proxy, set `PORTAL_HTTPS=1` for Secure session cookies, and expose only HTTPS to users. On Windows, run the gateway and server as managed background services under a dedicated account after the first interactive password setup. Back up `data/portal.sqlite3` with `python backup.py`; protect backups and verify restores. For broader HR use, review identity integration, MFA, monitoring, patching, retention, and access audits.

The server stores data in `data/portal.sqlite3`, outside Git. Do not commit it or a populated backup. See [GITHUB-AND-HOSTING.md](GITHUB-AND-HOSTING.md) for the exact steps.
